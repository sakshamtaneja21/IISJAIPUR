#!/usr/bin/env bash

echo 'Activating Environment'
source activate .conda3.6
python gui.py